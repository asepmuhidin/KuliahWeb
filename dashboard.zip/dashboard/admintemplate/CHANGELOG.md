# CHANGELOG

## V 2.0.0
- Improved design
- New folder structure
- Updated plugins to newer version
- Other bug fixes

## V 1.0.0
- Initial release
