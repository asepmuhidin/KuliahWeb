<?php
include $_SERVER['DOCUMENT_ROOT']."/websiteku/conn.php";

$sql="select * from mahasiswa ";

$rs=mysqli_query($con,$sql);

?>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Data Mahasiswa</h4>
                    <p class="card-description"> Data seluruh  <code>Mahasiswa</code></p>
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th> NIM </th>
                          <th> Nama Mahasiswa </th>
                          <th> Fakultas </th>
                          <th> Prodi</th>
                          <th> Email </th>
                          <th> Telp. </th>
                          <th> Alamat </th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php while($rec=mysqli_fetch_assoc($rs)):?>
                        <tr>
                          <td><?php echo $rec['nim']; ?></td>
                          <td><?php echo $rec['nama']; ?></td>
                          <td><?php echo $rec['fakultas']; ?></td>
                          <td><?php echo $rec['prodi']; ?></td>
                          <td><?php echo $rec['email']; ?></td>
                          <td><?php echo $rec['telp']; ?></td>
                          <td><?php echo $rec['alamat']; ?></td>
                        </tr>
                        <?php endwhile; ?> 
                       </tbody>
                    </table>
            </div>        
        </div>
    </div>
</div>
              